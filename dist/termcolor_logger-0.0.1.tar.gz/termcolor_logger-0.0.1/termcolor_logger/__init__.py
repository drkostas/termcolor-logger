from .colorized_logger import ColorLogger

__author__ = "drkostas"
__email__ = "georgiou.kostas94@gmail.com"
__version__ = "0.0.1"
